package aed;

public class ListaEnlazada<T> {
    // Completar atributos privados
    private int longitud;
    private Nodo Primero;
    private Nodo Ultimo;

    private class Nodo {
        T valor;
        Nodo siguiente;
        Nodo anterior;
        // Completar
        public Nodo(T elem) {
            this.valor = elem;
        }
    }

    public ListaEnlazada() {
        this.longitud = 0;
        return;
    }

    public int longitud() {
        return longitud;
    }

    public void agregarAdelante(T elem) {
        if (this.longitud == 0) {
            this.Primero.valor = elem;
            this.Ultimo = this.Primero;
        }
        else {
        this.Ultimo.siguiente = new Nodo(elem);
        this.Ultimo.siguiente.anterior = this.Ultimo;
        this.Ultimo = this.Ultimo.siguiente;
        }

    }

    public void agregarAtras(T elem) {
        throw new UnsupportedOperationException("No implementada aun");
    }

    public T obtener(int i) {
        throw new UnsupportedOperationException("No implementada aun");
    }

    public void eliminar(int i) {
        throw new UnsupportedOperationException("No implementada aun");
    }

    public void modificarPosicion(int indice, T elem) {
        throw new UnsupportedOperationException("No implementada aun");
    }

    public ListaEnlazada(ListaEnlazada<T> lista) {
        throw new UnsupportedOperationException("No implementada aun");
    }
    
    @Override
    public String toString() {
        throw new UnsupportedOperationException("No implementada aun");
    }

    public class ListaIterador{
    	// Completar atributos privados

        public boolean haySiguiente() {
	        throw new UnsupportedOperationException("No implementada aun");
        }
        
        public boolean hayAnterior() {
	        throw new UnsupportedOperationException("No implementada aun");
        }

        public T siguiente() {
	        throw new UnsupportedOperationException("No implementada aun");
        }
        

        public T anterior() {
	        throw new UnsupportedOperationException("No implementada aun");
        }
    }

    public ListaIterador iterador() {
	    throw new UnsupportedOperationException("No implementada aun");
    }

}
